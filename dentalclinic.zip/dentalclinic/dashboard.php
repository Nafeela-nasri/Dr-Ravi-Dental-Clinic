<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dental Clinic Dashboard</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    .chart-heading {
      font-size: 24px;
      color: #333;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .charts-wrapper {
      display: flex;
      justify-content: space-between;
      gap: 20px;
      flex-wrap: wrap;
      margin-top: 30px;
    }

    .chart-box {
      flex: 1;
      min-width: 30%;
      max-width: 32%;
      background: #f9fbff;
      padding: 24px 20px;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    canvas { max-width: 100%; }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 40px;
      background: #f9fbff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      border-radius: 12px;
      overflow: hidden;
    }

    table th, table td {
      padding: 12px 16px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }

    table th {
      background-color: #0056b3;
      color: white;
    }

    .table-title {
      margin-top: 60px;
      font-size: 22px;
      color: #333;
      font-weight: bold;
    }

    .kpi-cards-wrapper {
      display: flex;
      gap: 20px;
      flex-wrap: wrap;
      margin-top: 30px;
    }

    .kpi-card {
      flex: 1;
      min-width: 220px;
      background: #f9fbff;
      padding: 24px 20px;
      border-radius: 16px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .kpi-card .card-info {
      display: flex;
      flex-direction: column;
    }

    .kpi-card .card-label {
      font-size: 20px;
      font-weight: bold;
      color: #1a1a1a;
      margin-bottom: 6px;
    }

    .kpi-card .card-value {
      font-size: 26px;
      font-weight: 600;
      color: #0056b3;
    }

    .kpi-card .card-icon {
      font-size: 40px;
    }

    #ageChart {
      max-width: 250px;
      max-height: 250px;
    }

    .status {
      padding: 4px 8px;
      border-radius: 8px;
      font-size: 12px;
      font-weight: bold;
      text-transform: capitalize;
    }

    .status-confirmed { background: #d4edda; color: #155724; }
    .status-pending   { background: #fff3cd; color: #856404; }
    .status-on-process { background: #f8d7da; color: rgb(55, 28, 125); }
  </style>
</head>
<body>
<?php
require_once("include/database.php");

// Latest appointments
$sql = "SELECT a.*, p.Fname AS patient_name, d.first_name AS doctor_name 
        FROM tblappointments a 
        JOIN tblpatients p ON a.PatientID = p.PatientID 
        JOIN tbldoctors d ON a.Doctor_ID = d.Doctor_ID 
        ORDER BY a.appointment_date DESC, a.timeslot ASC 
        LIMIT 5";
$latestAppointments = $mydb->setQuery($sql)->loadResultList();

// KPI counts
$today = date('Y-m-d');
$counts = [
  "SELECT COUNT(*) as count FROM tblpatients" => 'patientCount',
  "SELECT COUNT(*) as count FROM tbldoctors" => 'doctorCount',
  "SELECT COUNT(*) as count FROM tblappointments WHERE appointment_date = '{$today}'" => 'appointmentCount',
  "SELECT COUNT(*) as count FROM tblservices" => 'serviceCount'
];

foreach ($counts as $query => $var) {
    $res = $mydb->setQuery($query);
    $$var = $res ? $res->loadSingleResult()->count : 0;
}

$cards = [
  ['icon' => '👥', 'label' => 'Total Patients', 'value' => $patientCount . '+'],
  ['icon' => '🩺', 'label' => 'Total Doctors', 'value' => $doctorCount],
  ['icon' => '📅', 'label' => 'Today\'s Appointments', 'value' => $appointmentCount],
  ['icon' => '📋', 'label' => 'Available Services', 'value' => $serviceCount],
];

// Last 7 days appointment stats
$appointmentLabels = $appointmentCounts = [];
for ($i = 6; $i >= 0; $i--) {
  $date = date('Y-m-d', strtotime("-$i days"));
  $appointmentLabels[] = date('M d', strtotime($date));
  $sql = "SELECT COUNT(*) as count FROM tblappointments WHERE appointment_date = '$date'";
  $result = $mydb->setQuery($sql);
  $appointmentCounts[] = $result ? $result->loadSingleResult()->count : 0;
}

// Age distribution
$ageGroups = ['0-18', '19-35', '36-50', '51-65', '66+'];
$ageCounts = [];
foreach ($ageGroups as $group) {
  switch ($group) {
    case '0-18': $sql = "SELECT COUNT(*) as count FROM tblpatients WHERE age BETWEEN 0 AND 18"; break;
    case '19-35': $sql = "SELECT COUNT(*) as count FROM tblpatients WHERE age BETWEEN 19 AND 35"; break;
    case '36-50': $sql = "SELECT COUNT(*) as count FROM tblpatients WHERE age BETWEEN 36 AND 50"; break;
    case '51-65': $sql = "SELECT COUNT(*) as count FROM tblpatients WHERE age BETWEEN 51 AND 65"; break;
    case '66+': $sql = "SELECT COUNT(*) as count FROM tblpatients WHERE age >= 66"; break;
  }
  $result = $mydb->setQuery($sql);
  $ageCounts[] = $result ? $result->loadSingleResult()->count : 0;
}

// Treatment Plan Status
$treatmentStatuses = ['Completed', 'Pending', 'On Process'];
$treatmentCounts = [];
foreach ($treatmentStatuses as $status) {
  $sql = "SELECT COUNT(*) as count FROM tbltreatmentplan WHERE status = '$status'";
  $result = $mydb->setQuery($sql);
  $treatmentCounts[] = $result ? $result->loadSingleResult()->count : 0;
}
?>

<!-- KPI Cards -->
<div class="kpi-cards-wrapper">
  <?php foreach ($cards as $card): ?>
    <div class="kpi-card">
      <div class="card-info">
        <div class="card-label"><?= $card['label'] ?></div>
        <div class="card-value"><?= $card['value'] ?></div>
      </div>
      <div class="card-icon"><?= $card['icon'] ?></div>
    </div>
  <?php endforeach; ?>
</div>

<!-- Appointments Table -->
<div class="table-title">Recent Appointments</div>
<table>
  <thead>
    <tr>
      <th>Patient Name</th>
      <th>Doctor</th>
      <th>Date</th>
      <th>Time Slot</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($latestAppointments as $appt): ?>
      <tr>
        <td><?= htmlspecialchars($appt->patient_name) ?></td>
        <td><?= htmlspecialchars($appt->doctor_name) ?></td>
        <td><?= date("M d, Y", strtotime($appt->appointment_date)) ?></td>
        <td><?= htmlspecialchars($appt->timeslot) ?></td>
        <td>
          <?php $statusClass = strtolower(str_replace(' ', '-', $appt->status)); ?>
          <span class="status status-<?= $statusClass ?>"><?= $appt->status ?></span>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<!-- Charts -->
<div class="charts-wrapper">
  <div class="chart-box">
    <h3 class="chart-heading">Appointments in the Last 7 Days</h3>
    <canvas id="appointmentsChart"></canvas>
  </div>
  <div class="chart-box">
    <h3 class="chart-heading">Age Group Distribution</h3>
    <canvas id="ageChart"></canvas>
  </div>
  <div class="chart-box">
    <h3 class="chart-heading">Treatment Plan Status</h3>
    <canvas id="treatmentChart"></canvas>
  </div>
</div>

<script>
  new Chart(document.getElementById('appointmentsChart'), {
    type: 'bar',
    data: {
      labels: <?= json_encode($appointmentLabels); ?>,
      datasets: [{
        label: 'Appointments',
        data: <?= json_encode($appointmentCounts); ?>,
        backgroundColor: '#36a2eb'
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });

  new Chart(document.getElementById('ageChart'), {
    type: 'pie',
    data: {
      labels: <?= json_encode($ageGroups); ?>,
      datasets: [{
        data: <?= json_encode($ageCounts); ?>,
        backgroundColor: ['#007bff', '#28a745', '#ffc107', '#dc3545', '#6c757d']
      }]
    },
    options: { responsive: true }
  });

  new Chart(document.getElementById('treatmentChart'), {
    type: 'bar',
    data: {
      labels: <?= json_encode($treatmentStatuses); ?>,
      datasets: [{
        label: 'Treatment Plans',
        data: <?= json_encode($treatmentCounts); ?>,
        backgroundColor: ['#28a745', '#ffc107', '#17a2b8']
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
</script>
</body>
</html>
