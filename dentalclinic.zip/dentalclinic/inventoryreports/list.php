<?php
require_once("../include/initialize.php");

if (!isset($_SESSION['ADMIN_USERID'])) {
  redirect(web_root . "admin/index.php");
}
?>

<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  }

  .row {
    margin-bottom: 10px;
  }

  .panel {
    background-color: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.1);
  }

  .panel-header {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 15px;
    text-align: center;
    color: #343a40;
  }

  .form-control {
    border-radius: 5px;
    box-shadow: none;
  }

  .btn-success {
    width: 100%;
    border-radius: 5px;
  }

  .btn-info {
    margin: 15px 0;
    border-radius: 5px;
  }

  .table {
    background: white;
    border: 1px solid #dee2e6;
  }

  .table thead {
    background-color: #007bff;
    color: white;
    text-align: center;
  }

  .table th, .table td {
    vertical-align: middle !important;
    text-align: center;
  }

  tfoot th {
    background-color: #f1f1f1;
    font-weight: bold;
  }

  @media print {
    .no-print, .no-print * {
      display: none !important;
    }

    body {
      margin: 0;
    }

    .table {
      width: 100%;
    }
  }
</style>

<form action="" method="POST">
  <section class="content-header no-print">
    <div class="col-md-3"> </div>
    <div class="col-md-6">
      <div class="panel">
        <div class="panel-header">Sales Report Filter</div>
        <div class="panel-body">
          <div class="row">
            <div class="col-sm-3"><label>Date From:</label></div>
            <div class="col-sm-9">
              <div class="input-group date">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input required autocomplete="off" type="text"
                  value="<?php echo isset($_POST['date_from']) ? $_POST['date_from'] : DATE('m/d/Y'); ?>"
                  name="date_from" class="form-control date_picker" placeholder="mm/dd/yyyy">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-3"><label>Date To:</label></div>
            <div class="col-sm-9">
              <div class="input-group date">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input required autocomplete="off" type="text"
                  value="<?php echo isset($_POST['date_to']) ? $_POST['date_to'] : DATE('m/d/Y'); ?>"
                  name="date_to" class="form-control date_picker" placeholder="mm/dd/yyyy">
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-9">
              <input type="submit" name="submit" class="btn btn-success" value="Generate Report">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3"> </div>
  </section>
</form>

<div class="clear"></div>

<section class="content col-sm-12">
  <p style="text-align: center; font-size: 18px; font-weight: bold;">
    Sales Report <br />
    As of <?php echo date('m/d/Y'); ?>
  </p>

  <p style="text-align: center; font-size: 15px;">
    Inclusive Dates:
    <?php echo isset($_POST['date_from']) ? "From: " . $_POST['date_from'] : "Month-Day-Year"; ?> |
    <?php echo isset($_POST['date_to']) ? "To: " . $_POST['date_to'] : "Month-Day-Year"; ?>
  </p>

  <div class="no-print text-center">
    <button type="button" class="btn btn-info" onclick="myFunction()">Print Report</button>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Services</th>
        <th width="120">Price</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $datefrom = isset($_POST['date_from']) ? date_format(date_create($_POST['date_from']), 'Y-m-d') : "";
      $dateto = isset($_POST['date_to']) ? date_format(date_create($_POST['date_to']), 'Y-m-d') : "";

      $totalprice = 0;

      $sql = "SELECT * FROM tblinvoice i, tblpayments p 
              WHERE i.InvoiceNo=p.InvoiceNo 
              AND DATE(`InvoiceDate`) >= '$datefrom' 
              AND DATE(`InvoiceDate`) <= '$dateto'";
      $mydb->setQuery($sql);
      $cur = $mydb->loadResultList();
      foreach ($cur as $result) {
        echo '<tr>';
        echo '<td>' . $result->Services . '</td>';
        echo '<td>' . number_format($result->Price, 2) . '</td>';
        echo '</tr>';
        $totalprice += $result->Price;
      }
      ?>
    </tbody>
    <tfoot>
      <tr>
        <th>Total</th>
        <th><?php echo number_format($totalprice, 2); ?></th>
      </tr>
    </tfoot>
  </table>

  <script>
    function myFunction() {
      window.print();
    }
  </script>
</section>
