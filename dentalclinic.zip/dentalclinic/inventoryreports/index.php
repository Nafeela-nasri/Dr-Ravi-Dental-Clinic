<?php
require_once("../include/initialize.php");
 if(!isset($_SESSION['ADMIN_USERID'])){
	redirect(web_root."admin/index.php");
}

$view = (isset($_GET['view']) && $_GET['view'] != '') ? $_GET['view'] : '';
 $title="Report"; 
 $header=$view; 
switch ($view) {
	case 'list' :
		$content    = 'list.php';		
		break;

	case 'add' :
		$content    = 'add.php';		
		break;

	case 'edit' :
		$content    = 'edit.php';		
		break;
    case 'view' :
		$content    = 'view.php';		
		break;

	case 'patientsreport' :
		$content    = 'patientsreport.php';		
		break;
	default :
		$content    = 'list.php';		
}
require_once ("../theme/templates.php");
?>
  
