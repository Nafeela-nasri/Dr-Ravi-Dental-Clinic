
<?php


require_once ("../include/initialize.php");
 	 if (!isset($_SESSION['ADMIN_USERID'])){
    redirect(web_root."admin/index.php");
    }

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
	
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

	


$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';

switch ($action) {
	
	case 'edit' :
		edit();
	break;
	
	case 'delete' :
	doDelete();
	break;
 
	}
	if ($_GET['action'] == 'insertevent') {
		$title = $_POST['title'];  
		$start = $_POST['start'];  
		$end = $_POST['end'];
	
		// Split time from datetime
		$time = date("H:i", strtotime($start));
		$date = date("Y-m-d", strtotime($start));
	
		// INSERT into tblappointments
		$sql = "INSERT INTO tblappointments (PatientID, Doctor_ID, reason, appointment_date, timeslot, status, created_at)
				VALUES ('0', '0', '$title', '$date', '$time', 'Booked', NOW())";
	
		$mydb->setQuery($sql);
		$mydb->executeQuery();
	}
	
?>
<?php
if ($_GET['action'] == 'add' && isset($_POST['save'])) {
    $PatientID        = $_POST['PatientID'];
    $Doctor_ID        = $_POST['Doctor_ID'];
    $appointment_date = $_POST['appointment_date'];
    $timeslot         = $_POST['timeslot'];
    $status           = $_POST['status'];

    $sql = "INSERT INTO tblappointments (PatientID, Doctor_ID, appointment_date, timeslot, status, created_at) 
            VALUES ('$PatientID', '$Doctor_ID', '$appointment_date', '$timeslot', '$status', NOW())";
    $mydb->setQuery($sql);

    if ($mydb->executeQuery()) {
        // Fetch patient details
        $mydb->setQuery("SELECT FullName, email FROM tblpatients WHERE PatientID = '$PatientID'");
        $patient = $mydb->loadSingleResult();

        // Fetch doctor name
        $mydb->setQuery("SELECT first_name FROM tbldoctors WHERE Doctor_ID = '$Doctor_ID'");
        $doctor = $mydb->loadSingleResult();

        $patientName = $patient->FullName ?? 'Valued Patient';
        $patientEmail ='nafeelanasri808@gmail.com';
        // $patientEmail =$patient->email;
        $doctorName = $doctor->first_name ?? 'Unknown';

        if (!empty($patientEmail) && filter_var($patientEmail, FILTER_VALIDATE_EMAIL)) {
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'nafeelanasri687@gmail.com';
                $mail->Password   = 'rllnlrqgviiuimwh'; // Your App Password (no spaces)
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Recipients
                $mail->setFrom("nafeelanasri687@gmail.com", "{$doctorName} DentalCare");
                $mail->addAddress($patientEmail, $patientName);

                // Content
                $mail->isHTML(true);
                $mail->Subject = "Appointment Confirmation :  {$doctorName} DentalCare";
                $mail->Body    = "
                    Dear {$patientName},<br><br>

                    Thank you for scheduling your appointment with  {$doctorName}DentalCare!<br><br>

                    <strong>Appointment Details:</strong><br>
                    Date: {$appointment_date}<br>
                    Time: {$timeslot}<br>
                    Doctor: Dr. {$doctorName}<br><br>

                    Please arrive 10-15 minutes early to complete any necessary paperwork. If you have any questions or need to reschedule, feel free to contact us!<br><br>

                    We look forward to seeing you and helping you maintain a healthy smile!<br><br>

                    Best regards,<br>
                    <strong> {$doctorName} DentalCare</strong>
                ";

                $mail->send();
                $_SESSION['message'] = "Appointment added and email sent successfully!";
            } catch (Exception $e) {
                $_SESSION['message'] = "Appointment added but email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $_SESSION['message'] = "Appointment added, but no valid email found to send confirmation.";
        }

        header("Location: index.php");
        exit;
    } else {
        echo "Error saving appointment.";
    }
}

function doDelete() {
    global $mydb;

    $id = isset($_GET['id']) ? $_GET['id'] : '';

    if (!empty($id)) {
        $sql = "DELETE FROM tblappointments WHERE id = '$id'";
        $mydb->setQuery($sql);

        if ($mydb->executeQuery()) {
			$_SESSION['message'] = "Appointment deleted successfully!";
			header("Location: index.php");
			exit;
        } else {
            echo "Error deleting appointment.";
        }
    } else {
        echo "No appointment ID provided.";
    }
}

function edit() {
    global $mydb;
    
    if (isset($_POST['save'])) {
        $id = $_POST['id'];
        $patientID = $_POST['PatientID'];
        $doctorID = $_POST['Doctor_ID'];
        $appointmentDate = $_POST['appointment_date'];
        $timeslot = $_POST['timeslot'];
        $status = $_POST['status'];

        $query = "UPDATE tblappointments 
                  SET PatientID = '$patientID', Doctor_ID = '$doctorID', appointment_date = '$appointmentDate', timeslot = '$timeslot', status = '$status'
                  WHERE id = '$id'";

        $mydb->setQuery($query);
        $mydb->executeQuery();
		if ($mydb->executeQuery()) {
			$_SESSION['message'] = "Appointment updated successfully!";
			header("Location: index.php");
			exit;
			
		} else {
			echo "Error updating appointment.";
		}
    }
}
?>
