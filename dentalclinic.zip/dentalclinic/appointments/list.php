<?php 
if (!isset($_SESSION['ADMIN_USERID'])) {
    redirect(web_root . "login.php");
}
?>
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            <a href="index.php?view=add" class="btn btn-primary btn-md">
                <i class="fa fa-plus-circle fw-fa"></i> Add Appointment
            </a>
        </h1>
    </div>
</div>

<?php
if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success alert-dismissible" role="alert" style="margin:10px 0;">
            <button type="button" class="close" data-dismiss="alert">&times;</button>'
            . $_SESSION['message'] .
          '</div>';
    unset($_SESSION['message']);
}
?>


<form action="controller.php?action=delete" Method="POST">
    <div class="table-responsive">
        <table id="dash-table" class="table table-striped table-bordered table-hover" style="font-size:12px" cellspacing="0">
            <thead>
                <tr>
                    <th>Appointment ID</th>
                    <th>Patient Name</th>
                    <th>Doctor Name</th>
                    <th>Appointment Date</th>
                    <th>Time Slot</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th width="10%">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $mydb->setQuery("SELECT a.*, 
                                        p.Fname AS PFname, p.Lname AS PLname, 
                                        d.first_name AS DFname, d.last_name AS DLname 
                                 FROM tblappointments a
                                 JOIN tblpatients p ON a.PatientID = p.PatientID
                                 JOIN tbldoctors d ON a.Doctor_ID = d.Doctor_ID");
                $appointments = $mydb->loadResultList();

                foreach ($appointments as $appt) {
                    echo '<tr>';
                    echo '<td>' . $appt->id . '</td>';
                    echo '<td>' . $appt->PLname . ' ' . $appt->PFname . '</td>';
                    echo '<td>Dr. ' . $appt->DFname . ' ' . $appt->DLname . '</td>';
                    echo '<td>' . $appt->appointment_date . '</td>';
                    echo '<td>' . $appt->timeslot . '</td>';
                    echo '<td>' . $appt->status . '</td>';
                    echo '<td>' . $appt->created_at . '</td>';
                    echo '<td align="center">';
                    echo '<a title="Edit" href="index.php?view=edit&id=' . $appt->id . '" class="btn btn-primary btn-md"><span class="fa fa-edit fw-fa"></span></a> ';
                    echo '<a title="Delete" href="controller.php?action=delete&id=' . $appt->id . '" class="btn btn-danger btn-md"><span class="fa fa-trash fw-fa"></span></a>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</form>
