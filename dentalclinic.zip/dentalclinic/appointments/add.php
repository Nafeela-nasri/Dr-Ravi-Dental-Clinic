<?php
require_once("../include/initialize.php"); 

if (!isset($_SESSION['ADMIN_USERID'])) {
    redirect(web_root . "login.php");
}
?>

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Add New Appointment</h1>
    </div>
</div>

<form class="form-horizontal span6" action="controller.php?action=add" method="POST">
    <div class="form-group">
        <label class="col-md-2 control-label" for="PatientID">Patient</label>
        <div class="col-md-8">
            <select class="form-control" name="PatientID" required>
                <option value="">Select Patient</option>
                <?php
                $mydb->setQuery("SELECT * FROM tblpatients");
                $patients = $mydb->loadResultList();
                foreach ($patients as $p) {
                    echo '<option value="' . $p->PatientID . '">' . $p->Lname . ', ' . $p->Fname . ' ' . $p->Mname . '</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-2 control-label" for="Doctor_ID">Doctor</label>
        <div class="col-md-8">
            <select class="form-control" name="Doctor_ID" required>
                <option value="">Select Doctor</option>
                <?php
                $mydb->setQuery("SELECT * FROM tbldoctors");
                $doctors = $mydb->loadResultList();
                foreach ($doctors as $d) {
                    echo '<option value="' . $d->Doctor_ID . '">' . 'Dr. ' . $d->first_name . ' ' . $d->last_name . '</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-2 control-label" for="appointment_date">Date</label>
        <div class="col-md-8">
            <input type="date" name="appointment_date" class="form-control" required />
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-2 control-label" for="timeslot">Time Slot</label>
        <div class="col-md-8">
            <select class="form-control" name="timeslot" required>
                <option value="">Select Time</option>
                <option value="09:00 AM - 10:00 AM">09:00 AM - 10:00 AM</option>
                <option value="10:00 AM - 11:00 AM">10:00 AM - 11:00 AM</option>
                <option value="11:00 AM - 12:00 PM">11:00 AM - 12:00 PM</option>
                <option value="01:00 PM - 02:00 PM">01:00 PM - 02:00 PM</option>
                <option value="02:00 PM - 03:00 PM">02:00 PM - 03:00 PM</option>
                <option value="03:00 PM - 04:00 PM">03:00 PM - 04:00 PM</option>
            </select>
        </div>
    </div>

    <div class="form-group">
        <label class="col-md-2 control-label" for="status">Status</label>
        <div class="col-md-8">
            <select class="form-control" name="status" required>
                <option value="">Select Status</option>
                <option value="Pending">Pending</option>
                <option value="Confirmed">Confirmed</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
            </select>
        </div>
    </div>

    <div class="form-group">
        <div class="col-md-offset-2 col-md-8">
            <button class="btn btn-primary btn-md" name="save" type="submit"><i class="fa fa-save fw-fa"></i> Save Appointment</button>
        </div>
    </div>
</form>
