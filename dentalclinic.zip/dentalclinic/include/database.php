<?php
require_once("config.php");

class Database {
    var $sql_string = '';
    var $error_no = 0;
    var $error_msg = '';
    private $conn;
    public $last_query;
    private $magic_quotes_active;
    private $real_escape_string_exists;

    function __construct() {
        $this->open_connection();
        $this->real_escape_string_exists = function_exists("mysqli_real_escape_string");
        $this->conn = mysqli_connect(server, user, pass, database_name);
    }

    public function open_connection() {
        $this->conn = mysqli_connect(server, user, pass);
        if(!$this->conn){
            echo "Problem in database connection! Contact administrator!";
            exit();
        } else {
            $db_select = mysqli_select_db($this->conn, database_name);
            if (!$db_select) {
                echo "Problem in selecting database! Contact administrator!";
                exit();
            }
        }
    }

    function setQuery($sql='') {
        $this->sql_string = $sql;
        return $this;
    }

    function executeQuery() {
        error_log("SQL Query: " . $this->sql_string);
        $result = mysqli_query($this->conn, $this->sql_string);
        if(!$result) {
            $this->error_no = mysqli_errno($this->conn);
            $this->error_msg = mysqli_error($this->conn);
            error_log("MySQL Error (" . $this->error_no . "): " . $this->error_msg);
        }
        $this->confirm_query($result);
        return $result;
    }

    private function confirm_query($result) {
        if(!$result){
            $this->error_no = mysqli_errno($this->conn);
            $this->error_msg = mysqli_error($this->conn);
            return false;                
        }
        return $result;
    }

    function loadResultList($key='') {
        $cur = $this->executeQuery();
        $array = array();
        if ($cur && is_object($cur)) {
            while ($row = mysqli_fetch_object($cur)) {
                if ($key) {
                    $array[$row->$key] = $row;
                } else {
                    $array[] = $row;
                }
            }
            mysqli_free_result($cur);
        } else {
            error_log("Invalid result returned from query: " . $this->sql_string);
        }
        return $array;
    }

    function loadSingleResult() {
        $cur = $this->executeQuery();
        if ($cur && is_object($cur)) {
            while ($row = mysqli_fetch_object($cur)) {
                return $row;
            }
            mysqli_free_result($cur);
        } else {
            error_log("Invalid result returned from query: " . $this->sql_string);
        }
    }

    function getFieldsOnOneTable($tbl_name) {
        $this->setQuery("DESC ".$tbl_name);
        $rows = $this->loadResultList();
        $f = array();
        for ($x = 0; $x < count($rows); $x++) {
            $f[] = $rows[$x]->Field;
        }
        return $f;
    }

    public function fetch_array($result) {
        return mysqli_fetch_array($result);
    }

    public function num_rows($result_set) {
        return mysqli_num_rows($result_set);
    }

    public function insert_id() {
        return mysqli_insert_id($this->conn);
    }

    public function affected_rows() {
        return mysqli_affected_rows($this->conn);
    }

    public function escape_value($value) {
        if ($this->real_escape_string_exists) {
            if ($this->magic_quotes_active) { $value = stripslashes($value); }
            $value = mysqli_real_escape_string($this->conn, $value);
        } else {
            if (!$this->magic_quotes_active) { $value = addslashes($value); }
        }
        return $value;
    }

    public function __destruct() {
        if (isset($this->conn)) {
            mysqli_close($this->conn);
            unset($this->conn);
        }
    }
}

// -------------------------------------
// USAGE SECTION: Place this after the class
// -------------------------------------

$mydb = new Database();

// --- TOTAL PATIENTS ---
$patientCount = 0;
$sql = "SELECT COUNT(*) as count FROM tblpatients";
$result = $mydb->setQuery($sql)->loadSingleResult();
if ($result) $patientCount = $result->count;
else echo "Error: Could not retrieve patient count.";

// --- TOTAL DOCTORS ---
$doctorCount = 0;
$sql = "SELECT COUNT(*) as count FROM tbldoctors";
$result = $mydb->setQuery($sql)->loadSingleResult();
if ($result) $doctorCount = $result->count;
else echo "Error: Could not retrieve doctor count.";

// --- TODAY'S APPOINTMENTS ---
$today = date('Y-m-d');
$appointmentCount = 0;
$sql = "SELECT COUNT(*) as count FROM tblappointments WHERE appointment_date = '{$today}'";
$result = $mydb->setQuery($sql)->loadSingleResult();
if ($result) $appointmentCount = $result->count;
else echo "Error: Could not retrieve today's appointment count.";

// --- TOTAL SERVICES ---
$serviceCount = 0;
$sql = "SELECT COUNT(*) as count FROM tblservices";
$result = $mydb->setQuery($sql)->loadSingleResult();
if ($result) $serviceCount = $result->count;
else echo "Error: Could not retrieve service count.";

?>
