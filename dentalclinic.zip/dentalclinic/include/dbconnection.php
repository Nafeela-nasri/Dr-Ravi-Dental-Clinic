<?php
// dbconnection.php

$server = "localhost"; // Replace with your server
$username = "root"; // Replace with your username
$password = ""; // Replace with your password
$dbname = "db_dentalclinic"; // Replace with your database name

// Create connection
$connection = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
?>
