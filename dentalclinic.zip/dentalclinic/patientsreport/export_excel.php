<?php
require '../vendor/autoload.php'; // Adjust path if needed
require_once("../include/initialize.php");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$datefrom = date_format(date_create($_POST['date_from']), 'Y-m-d');
$dateto = date_format(date_create($_POST['date_to']), 'Y-m-d');
$gender = $_POST['gender'];

$sql = "SELECT * FROM tblpatients 
        WHERE DATE(CreatedDate) >= '$datefrom' 
        AND DATE(CreatedDate) <= '$dateto'";

if ($gender !== "All") {
  $sql .= " AND Sex = '$gender'";
}

$mydb->setQuery($sql);
$patients = $mydb->loadResultList();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Patient Report');

// Headers
$sheet->fromArray(['Full Name', 'Address', 'Age', 'Sex', 'Contact No'], NULL, 'A1');

// Data
$row = 2;
foreach ($patients as $patient) {
  $sheet->setCellValue("A$row", $patient->Fname . ' ' . $patient->Lname);
  $sheet->setCellValue("B$row", $patient->F_Address);
  $sheet->setCellValue("C$row", $patient->Age);
  $sheet->setCellValue("D$row", $patient->Sex);
  $sheet->setCellValue("E$row", $patient->ContactNo);
  $row++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Patient_Report.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
