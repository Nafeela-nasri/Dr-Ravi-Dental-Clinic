<?php
require_once("../include/initialize.php");
require '../vendor/autoload.php';

use Dompdf\Dompdf;

$datefrom = date_format(date_create($_POST['date_from']), 'Y-m-d');
$dateto = date_format(date_create($_POST['date_to']), 'Y-m-d');
$gender = $_POST['gender'];

$sql = "SELECT * FROM tblpatients 
        WHERE DATE(CreatedDate) >= '$datefrom' 
        AND DATE(CreatedDate) <= '$dateto'";

if ($gender !== "All") {
  $sql .= " AND Sex = '$gender'";
}

$mydb->setQuery($sql);
$patients = $mydb->loadResultList();

// Build HTML
$html = '<h2 style="text-align:center;">Patient Record Report</h2>';
$html .= '<p style="text-align:center;">From: ' . $_POST['date_from'] . ' | To: ' . $_POST['date_to'] . ' | Gender: ' . $gender . '</p>';
$html .= '<table border="1" cellpadding="6" cellspacing="0" width="100%">
            <thead style="background:#007bff; color:white;">
              <tr>
                <th>Full Name</th><th>Address</th><th>Age</th><th>Sex</th><th>Contact No</th>
              </tr>
            </thead><tbody>';

foreach ($patients as $p) {
  $html .= '<tr>
    <td>' . $p->Fname . ' ' . $p->Lname . '</td>
    <td>' . $p->F_Address . '</td>
    <td>' . $p->Age . '</td>
    <td>' . $p->Sex . '</td>
    <td>' . $p->ContactNo . '</td>
  </tr>';
}
$html .= '</tbody></table>';

// Generate PDF
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream("Patient_Report.pdf", array("Attachment" => 1));
exit;
