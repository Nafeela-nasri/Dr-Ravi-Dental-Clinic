<?php 
require_once("include/initialize.php");

if(isset($_SESSION['ADMIN_USERID'])){
  redirect(web_root."index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Dental Clinic Login Page">
  <meta name="author" content="Your Name">
  <title>Dental Clinic - Login</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
  <!-- Custom CSS -->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, rgb(53, 1, 107), rgb(5, 42, 105));
      color: #fff;
    }
    .login-container {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }
    .card {
      border-radius: 10px;
      overflow: hidden;
    }
    .login-image img {
      width: 100%;
      height: auto;
      padding: 10px;
      border-radius: 10px 0 0 10px;
    }
  </style>
</head>
<body>
  <div class="container login-container">
    <div class="row justify-content-center">
      <div class="col-xl-10 col-lg-12 col-md-9">
        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="card-body p-0">
            <div class="row">
              <!-- Left side image -->
              <div class="col-lg-6 d-none d-lg-block login-image">
                <img src="dist/img/Dr.Ravi DentalCare.png" alt="Dental Clinic Logo">
              </div>
              <!-- Right side login form -->
              <div class="col-lg-6">
                <div class="p-5">
                  <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Login to Your Account</h1>
                    <div style="font-size: 12px">
                      <?php 
                        // Display any message from process.php
                        if(isset($_SESSION['message'])) {
                          echo $_SESSION['message'];
                          unset($_SESSION['message']);
                        }
                      ?>
                    </div>
                  </div>
                  <!-- Login Form -->
                  <form class="user" method="POST" action="process.php">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-user" id="user_email" name="user_email" placeholder="Enter Username..." required>
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user" id="user_pass" name="user_pass" placeholder="Password" required>
                    </div>
                    <button type="submit" name="btnLogin" class="btn btn-primary btn-user btn-block">
                      Login
                    </button>
                  </form> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
