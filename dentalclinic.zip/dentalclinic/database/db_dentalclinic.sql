-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 05:44 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_dentalclinic`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_event` datetime NOT NULL DEFAULT current_timestamp(),
  `end_event` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `start_event`, `end_event`) VALUES
(1, 'Janno E. Palacios', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'asdasd', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'asdasd', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'asdsad', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'sad', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'asdas', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'asdasd', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'asdas', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'sads', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'sa', '2020-12-18 06:00:00', '0000-00-00 00:00:00'),
(15, 'asd', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'asd', '2021-02-01 00:00:00', '2021-02-02 00:00:00'),
(17, 'janobe source code', '2021-02-02 00:00:00', '2021-02-03 00:00:00'),
(19, 'newgods, darkseid as / ', '2022-09-05 22:53:00', '2022-09-05 22:53:00'),
(20, 'SOURCECODE, JANOBE E / ', '2022-09-05 22:58:00', '2022-09-05 22:58:00'),
(21, ' / ', '2022-09-05 22:58:00', '2022-09-05 22:58:00'),
(22, 'newgods, darkseid as / Fillings', '2022-09-06 23:30:00', '2022-09-06 23:30:00'),
(32, 'nazeer, naffa / filling', '2025-02-28 03:40:00', '2025-02-28 03:40:00'),
(33, 'Nasri, mohammed / surgery', '2025-02-28 03:33:00', '2025-02-28 03:33:00'),
(35, 'nasri, fathima nusha / filling', '2025-03-01 09:57:00', '2025-03-01 09:57:00'),
(36, 'nazeer, naffa / crown', '2025-03-01 15:27:00', '2025-03-01 15:27:00'),
(37, 'nushrath, nihma / filling', '2025-03-05 15:31:00', '2025-03-05 15:31:00'),
(45, 'tom, jerry / crown', '2025-04-12 18:41:00', '2025-04-12 18:41:00'),
(46, 'Nasri, mohammed / bridge', '2025-04-12 18:42:00', '2025-04-12 18:42:00'),
(47, 'Nasri, mohammed / bridge', '2025-04-23 18:42:00', '2025-04-23 18:42:00'),
(49, 'Nasri, mohammed / ', '2025-04-19 18:43:00', '2025-04-19 18:43:00'),
(50, 'Nasri, mohammed / surgery', '2025-04-24 18:57:00', '2025-04-24 18:57:00'),
(51, 'Nasri, mohammed / bridge / Ravi', '2025-04-17 09:30:00', '2025-04-17 09:30:00'),
(52, 'nazeer, naffa  / bridge  / Ravi ', '2025-04-17 10:00:00', '2025-04-17 10:00:00'),
(55, 'susantha, saviska nafeela / crown / Ravi', '2025-04-18 04:00:00', '2025-04-18 04:00:00'),
(59, 'Nasri, mohammed / filling / Ravi', '2025-04-25 01:30:00', '2025-04-25 01:30:00'),
(61, 'raj, shakthi / bridge / Ravi', '2025-04-26 10:00:00', '2025-04-26 10:00:00'),
(62, 'nushrath, nihma / Braces Procedures / Ravi', '2025-04-25 02:30:00', '2025-04-25 02:30:00'),
(64, 'nasri, fathima nusha / crown / Ravi', '2025-04-29 01:30:00', '2025-04-29 01:30:00'),
(65, 'nasri, fathima nusha / crown / Ravi', '2025-04-29 11:00:00', '2025-04-29 11:00:00'),
(66, 'brayan, sanda / crown / Ravi', '2025-04-20 09:00:00', '2025-04-20 09:00:00'),
(67, 'Nasri, mohammed / Braces Procedures / Ravi', '2025-04-22 10:30:00', '2025-04-22 10:30:00'),
(68, 'Nasri, mohammed / Braces Procedures / Ravi', '2025-04-30 02:00:00', '2025-04-30 02:00:00'),
(69, 'nasri, fathima nusha / Braces Procedures / Ravi', '2025-04-21 01:00:00', '2025-04-21 01:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblappointments`
--

CREATE TABLE `tblappointments` (
  `id` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `Doctor_ID` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `timeslot` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `ServiceID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblappointments`
--

INSERT INTO `tblappointments` (`id`, `PatientID`, `Doctor_ID`, `appointment_date`, `timeslot`, `status`, `created_at`, `ServiceID`) VALUES
(4, 51, 1, '2025-04-15', '10:00 AM - 11:00 AM', 'Completed', '2025-04-12 12:20:35', NULL),
(5, 36, 1, '2025-04-16', '2:00 PM - 3:00 PM', 'Pending', '2025-04-12 12:20:35', NULL),
(6, 39, 1, '2025-04-17', '11:00 AM - 12:00 PM', 'Pending', '2025-04-12 12:20:35', NULL),
(8, 36, 1, '2025-04-30', '10:00 AM', 'Pending', '2025-04-12 14:50:06', NULL),
(9, 36, 1, '2025-04-13', '10:00 AM', 'Pending', '2025-04-12 14:53:44', NULL),
(10, 45, 1, '2025-04-13', '11:00 AM', 'Pending', '2025-04-12 14:55:37', NULL),
(13, 34, 1, '2025-04-24', '11:00 AM - 12:00 PM', 'Confirmed', '2025-04-19 23:21:44', NULL),
(14, 49, 1, '2025-04-26', '01:00 PM - 02:00 PM', 'Confirmed', '2025-04-19 23:23:10', NULL),
(15, 50, 1, '2025-04-30', '03:00 PM - 04:00 PM', 'Pending', '2025-04-19 23:58:55', NULL),
(16, 70, 1, '2025-04-09', '09:00 AM - 10:00 AM', 'Confirmed', '2025-04-21 16:07:06', NULL),
(17, 70, 1, '2025-04-09', '09:00 AM - 10:00 AM', 'Confirmed', '2025-04-21 16:07:08', NULL),
(18, 70, 1, '2025-04-22', '01:00 PM - 02:00 PM', 'Pending', '2025-04-21 16:07:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumbers`
--

CREATE TABLE `tblautonumbers` (
  `AUTOID` int(11) NOT NULL,
  `AUTOSTART` varchar(90) NOT NULL,
  `AUTOEND` int(11) NOT NULL,
  `AUTOINC` int(11) NOT NULL,
  `AUTOKEY` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumbers`
--

INSERT INTO `tblautonumbers` (`AUTOID`, `AUTOSTART`, `AUTOEND`, `AUTOINC`, `AUTOKEY`) VALUES
(2, 'USER_0', 17, 1, 'USERID'),
(3, 'INV_0', 104, 1, 'INVOICENO'),
(4, '0000', 30, 1, 'SKU'),
(5, 'QUOTE_00', 5, 1, 'QUOTENO'),
(6, 'PR00', 10, 1, 'PROID');

-- --------------------------------------------------------

--
-- Table structure for table `tblbulkpricing`
--

CREATE TABLE `tblbulkpricing` (
  `BulkID` int(11) NOT NULL,
  `SKU` varchar(90) NOT NULL,
  `QTY` int(11) NOT NULL,
  `Price` double NOT NULL,
  `ModifiedDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbulkpricing`
--

INSERT INTO `tblbulkpricing` (`BulkID`, `SKU`, `QTY`, `Price`, `ModifiedDate`) VALUES
(10, '00003', 3, 890, '2019-07-10'),
(11, '00003', 5, 1450, '2019-07-10'),
(12, '00002', 2, 60, '2019-07-10'),
(16, '00002', 3, 80, '2020-12-08'),
(17, '00002', 5, 100, '2020-12-08'),
(18, '000013', 2, 500, '2020-12-10'),
(19, '000013', 3, 700, '2020-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `tblcurrency`
--

CREATE TABLE `tblcurrency` (
  `CurrencyID` int(11) NOT NULL,
  `CurrencySymbol` varchar(90) NOT NULL,
  `ActiveCurrency` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcurrency`
--

INSERT INTO `tblcurrency` (`CurrencyID`, `CurrencySymbol`, `ActiveCurrency`) VALUES
(6, 'Rs', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbldiscountrate`
--

CREATE TABLE `tbldiscountrate` (
  `DiscountRateID` int(11) NOT NULL,
  `DiscountRate` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbldoctors`
--

CREATE TABLE `tbldoctors` (
  `Doctor_ID` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `address` text DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `notification_preference` varchar(50) DEFAULT NULL,
  `profile_settings` text DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbldoctors`
--

INSERT INTO `tbldoctors` (`Doctor_ID`, `first_name`, `last_name`, `age`, `email`, `mobile_no`, `address`, `qualification`, `notification_preference`, `profile_settings`, `designation`) VALUES
(1, 'Ravi', '', 40, 'drravi@example.com', '0771234567', 'No. 45, Lake Road, Colombo', 'BDS', 'email', 'default', 'Dentist');

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--

CREATE TABLE `tblinvoice` (
  `InvoiceID` int(11) NOT NULL,
  `InvoiceNo` varchar(90) NOT NULL,
  `SKU` varchar(90) NOT NULL,
  `ToothNumber` int(11) DEFAULT 0,
  `Services` varchar(255) NOT NULL,
  `Price` double NOT NULL,
  `QTY` int(11) NOT NULL,
  `SubTotal` double NOT NULL,
  `Remarks` text NOT NULL,
  `UserID` varchar(90) NOT NULL,
  `Class` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinvoice`
--

INSERT INTO `tblinvoice` (`InvoiceID`, `InvoiceNo`, `SKU`, `ToothNumber`, `Services`, `Price`, `QTY`, `SubTotal`, `Remarks`, `UserID`, `Class`) VALUES
(47, 'INV_078', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_06', 'Invoice'),
(49, 'INV_079', '000021', 3, 'surgery ( no tooth only the root and a small part is remailing  )', 10000, 1, 10000, '', 'USER_06', 'Invoice'),
(50, 'INV_080', '000021', 3, 'surgery ( no tooth only the root and a small part is remailing  )', 10000, 1, 10000, '', 'USER_06', 'Invoice'),
(52, 'INV_080', '000023', 13, 'x ray  ( to scan the tooth  )', 1000, 1, 1000, '', 'USER_06', 'Invoice'),
(53, 'INV_081', '000021', 13, 'surgery ( no tooth only the root and a small part is remailing  )', 10000, 1, 10000, '', 'USER_06', 'Invoice'),
(54, 'INV_081', '000023', 13, 'x ray  ( to scan the tooth  )', 1000, 1, 1000, '', 'USER_06', 'Invoice'),
(55, 'INV_082', '000021', 13, 'surgery ( no tooth only the root and a small part is remailing  )', 10000, 1, 10000, '', 'USER_06', 'Invoice'),
(56, 'INV_082', '000023', 13, 'x ray  ( to scan the tooth  )', 1000, 1, 1000, '', 'USER_06', 'Invoice'),
(58, 'INV_083', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_06', 'Invoice'),
(59, 'INV_085', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_06', 'Invoice'),
(60, 'INV_086', '000020', 14, 'crown ( teeth is fully damaged we will have to add a crown )', 28000, 1, 28000, '', 'USER_015', 'Invoice'),
(61, 'INV_087', '000022', 22, 'bridge  ( the teeth is full of cavity so we will have to remove it add a bridge and add a crown  )', 67000, 1, 67000, '', 'USER_014', 'Invoice'),
(62, 'INV_087', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_014', 'Invoice'),
(63, 'INV_088', '000022', 22, 'bridge  ( the teeth is full of cavity so we will have to remove it add a bridge and add a crown  )', 67000, 1, 67000, '', 'USER_014', 'Invoice'),
(64, 'INV_089', '000020', 14, 'crown ( teeth is fully damaged we will have to add a crown )', 28000, 1, 28000, '', 'USER_014', 'Invoice'),
(65, 'INV_091', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_014', 'Invoice'),
(67, 'INV_0101', '000027', 12, 'Braces Procedures ( Braces Procedures  )', 1750000, 1, 1750000, '', 'USER_014', 'Invoice'),
(68, 'INV_0102', '000024', 4, 'filling ( --- )', 3456, 1, 3456, '', 'USER_014', 'Invoice'),
(69, 'INV_0103', '000019', 3, 'filling  ( The starting stage of cavity  )', 5000, 1, 5000, '', 'USER_014', 'Invoice');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatients`
--

CREATE TABLE `tblpatients` (
  `PatientID` int(11) NOT NULL,
  `Fname` varchar(90) NOT NULL,
  `Lname` varchar(90) NOT NULL,
  `Mname` varchar(90) NOT NULL,
  `F_Address` text NOT NULL,
  `Sex` varchar(90) NOT NULL,
  `Age` int(11) NOT NULL,
  `ContactNo` varchar(90) NOT NULL,
  `CreatedDate` datetime DEFAULT current_timestamp(),
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatients`
--

INSERT INTO `tblpatients` (`PatientID`, `Fname`, `Lname`, `Mname`, `F_Address`, `Sex`, `Age`, `ContactNo`, `CreatedDate`, `email`) VALUES
(34, '', '', '', '', '', 0, '', '2025-04-15 20:27:34', 'example34@mail.com'),
(36, 'fathima', 'nasri', 'nusha', '134 Peradeniya , Kandy', 'Female', 5, '07456261262', '2025-04-15 20:27:34', 'fathima.nasri@mail.com'),
(39, 'nihma', 'nushrath', '', 'madawala', 'Female', 19, '077854545', '2025-04-15 20:27:34', 'nihma.nushrath@mail.com'),
(40, 'nazeer', 'yakub', '', 'geliyoya', 'Male', 15, '077435678', '2025-04-15 20:27:34', 'nazeer.yakub@mail.com'),
(41, 'naffa', 'nazeer', '', 'kandy', 'Female', 15, '0777845626', '2025-04-15 20:27:34', 'naffa.nazeer@mail.com'),
(43, '', 'nasri', 'nashath', '789 Peradeniya kandy ', 'Male', 11, '07795952658', '2025-04-15 20:27:34', 'nasri.nashath@mail.com'),
(45, 'mohammed nasri', 'fathima nafeela', 'nafeela', '104/3 dehigama,muruthalawa', 'Female', 65, '0777457678', '2025-04-15 20:27:34', 'mohammed.nasri@mail.com'),
(46, 'nasvi', 'saleem', '', '10 Peradeniya kandy', 'Male', 49, '0778462546', '2025-04-15 20:27:34', 'nasvi.saleem@mail.com'),
(48, 'aysha', 'bee bee', 'nafeela', '156 , Peradeniya kandy', 'Female', 0, '0812410687', '2025-04-15 20:27:34', 'aysha.bee@mail.com'),
(49, '', '', '', '', '', 0, '', '2025-04-15 20:27:34', 'example49@mail.com'),
(50, 'saviska', 'susantha', 'nafeela', '104/3 geliyoya kandy', 'Male', 18, '0779565646', '2025-04-15 20:27:34', 'saviska.susantha@mail.com'),
(51, '', '', '', '', '', 0, '', '2025-04-15 20:27:34', 'example51@mail.com'),
(52, '', '', '', '', '', 0, '', '2025-04-15 20:27:34', 'example52@mail.com'),
(54, 'john', 'mickel', '', '56 hirasagalla kandy', 'Male', 16, '0775465466', '2025-04-15 20:27:34', 'john.mickel@mail.com'),
(55, 'jerry', 'tom', '', '76 kandy', 'Male', 17, '074845465', '2025-04-15 20:27:34', 'jerry.tom@mail.com'),
(58, 'nafee', '', '', 'kandy', 'Female', 14, '075461656', '2025-04-15 20:27:34', 'nafee.kandy@mail.com'),
(61, 'lml', 'lm', '', ',.m,.;l', 'Male', 16, '0777541', '2025-04-15 23:04:27', 'lml.lm@mail.com'),
(62, 'ruzna', 'razeen', '', 'geliyoya', 'Female', 74, '07794959899', '2025-04-15 23:07:32', 'ruzna.razeen@mail.com'),
(65, 'nawfal', 'nazeer', '', '14/b, yahalathenna ', 'Male', 26, '07781962634', '2025-04-16 08:54:41', 'nawfal.nazeer@mail.com'),
(67, '', '', '', '', '', 55, '', '2025-04-16 12:30:59', ''),
(68, 'barbie', '', '', 'kandy', 'Male', 16, '07775698589', '2025-04-16 13:39:24', 'barbie.kandy@mail.com'),
(69, 'nafeela', 'nasri', '', '104/3 dehigama,muruthalawa', 'Male', 17, '0778464645', '2025-04-19 22:28:40', 'nafeelanasri687@gmail.com'),
(70, '', '', '', '', '', 0, '', '2025-04-21 16:06:38', 'centralclinic40@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblpayments`
--

CREATE TABLE `tblpayments` (
  `PaymentID` int(11) NOT NULL,
  `ORNO` varchar(90) NOT NULL,
  `InvoiceDate` date NOT NULL,
  `DateDue` date NOT NULL,
  `InvoiceNo` varchar(90) NOT NULL,
  `TotalQTY` int(11) NOT NULL,
  `TotalAmount` double NOT NULL,
  `Payment` double NOT NULL,
  `Balance` double NOT NULL,
  `PaymentDate` datetime NOT NULL,
  `Patients` varchar(90) NOT NULL,
  `UserID` varchar(90) NOT NULL,
  `Status` text NOT NULL,
  `Class` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpayments`
--

INSERT INTO `tblpayments` (`PaymentID`, `ORNO`, `InvoiceDate`, `DateDue`, `InvoiceNo`, `TotalQTY`, `TotalAmount`, `Payment`, `Balance`, `PaymentDate`, `Patients`, `UserID`, `Status`, `Class`) VALUES
(15, '', '2025-02-27', '2025-02-28', 'INV_078', 0, 5000, 0, 0, '0000-00-00 00:00:00', 'Nasri, mohammed', 'USER_06', '', 'Invoice'),
(16, '', '2025-02-28', '2025-02-28', 'INV_079', 0, 10000, 0, 0, '0000-00-00 00:00:00', 'yakub, nazeer', 'USER_06', '', 'Invoice'),
(17, '', '2025-02-28', '2025-02-28', 'INV_080', 2, 11000, 0, 0, '0000-00-00 00:00:00', 'nasri, fathima nusha', 'USER_06', '', 'Invoice'),
(18, '', '2025-02-28', '2025-02-28', 'INV_081', 0, 11000, 0, 0, '0000-00-00 00:00:00', 'nasri, fathima nusha', 'USER_06', '', 'Invoice'),
(19, '', '2025-02-28', '2025-02-28', 'INV_082', 0, 11000, 0, 0, '0000-00-00 00:00:00', 'nasri, fathima nusha', 'USER_06', 'Paid', 'Invoice'),
(20, '', '2025-02-27', '2025-02-28', 'INV_083', 0, 5000, 0, 0, '0000-00-00 00:00:00', 'Nasri, mohammed', 'USER_06', 'Paid', 'Invoice'),
(22, '', '2025-03-01', '2025-03-01', 'INV_085', 0, 5000, 0, 0, '0000-00-00 00:00:00', 'nushrath, nihma', 'USER_06', 'Paid', 'Invoice'),
(23, '', '2025-04-10', '2025-04-10', 'INV_086', 0, 28000, 0, 0, '0000-00-00 00:00:00', 'NONE', 'USER_015', '', 'Invoice'),
(24, '', '2025-04-10', '2025-04-10', 'INV_087', 0, 72000, 0, 0, '0000-00-00 00:00:00', 'NONE', 'USER_014', '', 'Invoice'),
(25, '', '2025-04-10', '2025-04-10', 'INV_088', 0, 67000, 0, 0, '0000-00-00 00:00:00', 'Nasri, mohammed', 'USER_014', '', 'Invoice'),
(26, '', '2025-04-12', '2025-04-12', 'INV_089', 0, 28000, 0, 0, '0000-00-00 00:00:00', 'Nasri, mohammed', 'USER_014', '', 'Invoice'),
(27, '', '2025-04-12', '2025-04-12', 'INV_090', 0, 0, 0, 0, '0000-00-00 00:00:00', 'NONE', 'USER_014', '', 'Invoice'),
(28, '', '2025-04-13', '2025-04-13', 'INV_091', 0, 5000, 0, 0, '0000-00-00 00:00:00', 'tom, jerry', 'USER_014', '', 'Invoice'),
(29, '', '2025-04-16', '2025-04-16', 'INV_092', 0, 0, 0, 0, '0000-00-00 00:00:00', 'NONE', 'USER_014', '', 'Invoice'),
(30, '', '2025-04-17', '2025-04-17', 'INV_093', 0, 0, 0, 0, '0000-00-00 00:00:00', ',', 'USER_015', '', 'Invoice'),
(31, '', '2025-04-17', '2025-04-17', 'INV_094', 0, 0, 0, 0, '0000-00-00 00:00:00', 'nazeer, naffa', 'USER_015', '', 'Invoice'),
(32, '', '2025-04-17', '2025-04-17', 'INV_095', 0, 0, 0, 0, '0000-00-00 00:00:00', 'nasri, fathima nusha', 'USER_014', '', 'Invoice'),
(33, '', '2025-04-18', '2025-04-18', 'INV_096', 0, 0, 0, 0, '0000-00-00 00:00:00', ', barbie', 'USER_014', '', 'Invoice'),
(34, '', '2025-04-18', '2025-04-18', 'INV_097', 0, 0, 0, 0, '0000-00-00 00:00:00', ', barbie', 'USER_014', 'Paid', 'Invoice'),
(35, '', '2025-04-18', '2025-04-18', 'INV_098', 0, 0, 0, 0, '0000-00-00 00:00:00', 'nushrath, nihma', 'USER_014', '', 'Invoice'),
(36, '', '2025-04-18', '2025-04-18', 'INV_099', 0, 0, 0, 0, '0000-00-00 00:00:00', 'Nasri, mohammed', 'USER_014', '', 'Invoice'),
(37, '', '2025-04-18', '2025-04-18', 'INV_0100', 0, 0, 0, 0, '0000-00-00 00:00:00', 'nasri, fathima nusha', 'USER_014', '', 'Invoice'),
(38, '', '2025-04-18', '2025-04-18', 'INV_0101', 0, 1750000, 0, 0, '0000-00-00 00:00:00', ', barbie', 'USER_014', 'Paid', 'Invoice'),
(39, '', '2025-04-18', '2025-04-18', 'INV_0102', 0, 3456, 0, 0, '0000-00-00 00:00:00', 'nazeer, naffa', 'USER_014', '', 'Invoice'),
(40, '', '2025-04-21', '2025-04-21', 'INV_0103', 0, 5000, 0, 0, '0000-00-00 00:00:00', 'nushrath, nihma', 'USER_014', '', 'Invoice');

-- --------------------------------------------------------

--
-- Table structure for table `tblprescriptions`
--

CREATE TABLE `tblprescriptions` (
  `Prescriptions_ID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `Doctor_ID` int(11) NOT NULL,
  `DateIssued` date DEFAULT NULL,
  `Instructions` text DEFAULT NULL,
  `Status` enum('Not Given','Printed','Mailed') DEFAULT 'Not Given'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblprescriptions`
--

INSERT INTO `tblprescriptions` (`Prescriptions_ID`, `PatientID`, `Doctor_ID`, `DateIssued`, `Instructions`, `Status`) VALUES
(1, 51, 1, '2025-04-16', 'Take one tablet every 8 hours', 'Printed'),
(2, 52, 1, '2025-04-15', 'Apply cream twice a day', 'Mailed'),
(3, 54, 1, '2025-04-14', 'Take 2 tablets daily', 'Not Given'),
(4, 52, 1, '0000-00-00', 'jklnm', 'Not Given'),
(5, 34, 1, '0000-00-00', 'dlgkmfknfk', 'Not Given'),
(6, 40, 1, '0000-00-00', 'n,n', 'Not Given'),
(7, 50, 1, '0000-00-00', 'nkj', 'Not Given'),
(8, 39, 1, '0000-00-00', 'm', 'Not Given'),
(9, 55, 1, '2025-04-16', 'm', 'Not Given'),
(10, 61, 1, '2025-04-16', 'kln', 'Not Given'),
(11, 68, 1, '2025-04-18', 'ghh', 'Not Given'),
(12, 34, 1, '0000-00-00', ',mlk', 'Not Given'),
(13, 48, 1, '0000-00-00', 'better to have the medicine on time ', 'Not Given'),
(14, 54, 1, '0000-00-00', 'kjhjk', 'Not Given');

-- --------------------------------------------------------

--
-- Table structure for table `tblprescription_items`
--

CREATE TABLE `tblprescription_items` (
  `Item_ID` int(11) NOT NULL,
  `Prescriptions_ID` int(11) NOT NULL,
  `DosageName` varchar(255) DEFAULT NULL,
  `Frequency` varchar(50) DEFAULT NULL,
  `Duration` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblprescription_items`
--

INSERT INTO `tblprescription_items` (`Item_ID`, `Prescriptions_ID`, `DosageName`, `Frequency`, `Duration`) VALUES
(1, 1, 'Paracetamol', 'Every 8 hours', '7 days'),
(2, 2, 'Hydrocortisone Cream', 'Twice a day', '14 days'),
(3, 3, 'Aspirin', 'Once a day', '30 days');

-- --------------------------------------------------------

--
-- Table structure for table `tblprintfooter`
--

CREATE TABLE `tblprintfooter` (
  `PFID` int(11) NOT NULL,
  `FirstLine` varchar(255) NOT NULL,
  `SecondLine` varchar(255) NOT NULL,
  `ThirdLine` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblprintfooter`
--

INSERT INTO `tblprintfooter` (`PFID`, `FirstLine`, `SecondLine`, `ThirdLine`) VALUES
(1, 'Prices includes Dental Clinic where applicable', '', 'Thank you for the visit Get well soon!');

-- --------------------------------------------------------

--
-- Table structure for table `tblprintheader`
--

CREATE TABLE `tblprintheader` (
  `PHID` int(11) NOT NULL,
  `FirstLine` varchar(255) NOT NULL,
  `SecondLine` varchar(255) NOT NULL,
  `ThirdLine` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblprintheader`
--

INSERT INTO `tblprintheader` (`PHID`, `FirstLine`, `SecondLine`, `ThirdLine`) VALUES
(1, 'Receipt of Dr.Ravi Doctor', 'Dr. Ravi Weerasignhe', '663/3 Peradeniya Road, \r\nKandy');

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

CREATE TABLE `tblservices` (
  `ServiceID` int(11) NOT NULL,
  `SKU` varchar(90) NOT NULL,
  `ToothNumber` int(11) NOT NULL DEFAULT 0,
  `Services` text NOT NULL,
  `Description` text NOT NULL,
  `OriginalPrice` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblservices`
--

INSERT INTO `tblservices` (`ServiceID`, `SKU`, `ToothNumber`, `Services`, `Description`, `OriginalPrice`) VALUES
(19, '000019', 3, 'filling ', 'The starting stage of cavity ', 5000),
(20, '000020', 14, 'crown', 'teeth is fully damaged we will have to add a crown', 28000),
(21, '000021', 13, 'surgery', 'no tooth only the root and a small part is remailing ', 10000),
(22, '000022', 22, 'bridge ', 'the teeth is full of cavity so we will have to remove it add a bridge and add a crown ', 67000),
(23, '000023', 13, 'x ray ', 'to scan the tooth ', 1000),
(24, '000024', 4, 'filling', '---', 3456),
(25, '000025', 14, 'plantation', 'plantation', 200000),
(26, '000026', 17, 'Root Canal Treatment (RCT)', 'Root Canal Treatment (RCT)', 20000),
(27, '000027', 12, 'Braces Procedures', 'Braces Procedures ', 1750000),
(28, '000028', 1, 'Teeth Cleaning', 'full moth cleaning', 11000);

-- --------------------------------------------------------

--
-- Table structure for table `tblstocks`
--

CREATE TABLE `tblstocks` (
  `StocksID` int(11) NOT NULL,
  `ProductID` varchar(90) NOT NULL,
  `Products` varchar(90) NOT NULL,
  `Brand` varchar(90) NOT NULL,
  `Category` varchar(90) NOT NULL,
  `Description` text NOT NULL,
  `Price` double NOT NULL,
  `Stocks` int(11) NOT NULL,
  `DateReceived` datetime NOT NULL DEFAULT current_timestamp(),
  `Sold` int(11) NOT NULL,
  `DateSold` datetime NOT NULL DEFAULT current_timestamp(),
  `Expired` double NOT NULL,
  `DateExpired` datetime NOT NULL DEFAULT current_timestamp(),
  `Balance` double NOT NULL,
  `Remarks` text NOT NULL,
  `Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblstocks`
--

INSERT INTO `tblstocks` (`StocksID`, `ProductID`, `Products`, `Brand`, `Category`, `Description`, `Price`, `Stocks`, `DateReceived`, `Sold`, `DateSold`, `Expired`, `DateExpired`, `Balance`, `Remarks`, `Status`) VALUES
(36, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 06:10:59', 1, '2020-12-18 06:11:07', 0, '2020-12-18 06:10:59', 0, '', ''),
(37, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 06:11:02', 1, '2020-12-18 06:11:07', 0, '2020-12-18 06:11:02', 0, '', ''),
(38, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 06:11:02', 1, '2020-12-18 22:21:03', 0, '2020-12-18 06:11:02', 0, '', ''),
(39, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(40, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(41, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(42, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(43, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(44, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(45, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(46, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(47, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(48, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(49, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(50, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(51, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(52, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(53, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(54, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(55, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(56, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(57, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:21:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(58, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(59, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(60, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:55', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:55', 0, '', ''),
(61, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(62, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(63, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(64, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(65, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(66, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(67, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(68, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(69, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(70, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(71, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(72, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(73, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(74, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(75, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(76, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(77, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(78, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(79, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(80, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(81, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(82, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:03', 0, '2020-12-18 22:20:56', 0, '', ''),
(83, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(84, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(85, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(86, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(87, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(88, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(89, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(90, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(91, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(92, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(93, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(94, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(95, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(96, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(97, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(98, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(99, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(100, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(101, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(102, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(103, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(104, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(105, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(106, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(107, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:07', 0, '2020-12-18 22:20:56', 0, '', ''),
(108, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:46', 0, '2020-12-18 22:20:56', 0, '', ''),
(109, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:46', 0, '2020-12-18 22:20:56', 0, '', ''),
(110, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:46', 0, '2020-12-18 22:20:56', 0, '', ''),
(111, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:46', 0, '2020-12-18 22:20:56', 0, '', ''),
(112, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:50', 0, '2020-12-18 22:20:56', 0, '', ''),
(113, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:50', 0, '2020-12-18 22:20:56', 0, '', ''),
(114, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:50', 0, '2020-12-18 22:20:56', 0, '', ''),
(115, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:50', 0, '2020-12-18 22:20:56', 0, '', ''),
(116, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:50', 0, '2020-12-18 22:20:56', 0, '', ''),
(117, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(118, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(119, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(120, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(121, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(122, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(123, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 1, '2020-12-18 22:22:55', 0, '2020-12-18 22:20:56', 0, '', ''),
(124, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(125, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(126, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(127, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(128, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(129, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(130, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(131, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(132, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(133, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(134, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(135, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(136, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(137, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(138, 'PR008', 'as', 'sad', 'asd', 'asd', 0, 1, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '2020-12-18 22:20:56', 0, '', ''),
(139, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:39', 1, '2021-02-22 18:34:14', 0, '2021-02-22 18:33:39', 0, '', ''),
(140, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 1, '2021-02-22 18:34:14', 0, '2021-02-22 18:33:56', 0, '', ''),
(141, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 1, '2021-02-22 18:34:14', 0, '2021-02-22 18:33:56', 0, '', ''),
(142, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(143, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(144, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(145, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(146, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(147, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(148, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '2021-02-22 18:33:56', 0, '', ''),
(149, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(150, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(151, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(152, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(153, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(154, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(155, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(156, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(157, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(158, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(159, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(160, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(161, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(162, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(163, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(164, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(165, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(166, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(167, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(168, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(169, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(170, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(171, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(172, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(173, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(174, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(175, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(176, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(177, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(178, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(179, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(180, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(181, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(182, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(183, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(184, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(185, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(186, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(187, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(188, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(189, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(190, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(191, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(192, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(193, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(194, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(195, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(196, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(197, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(198, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(199, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(200, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(201, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(202, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(203, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(204, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(205, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(206, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(207, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(208, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(209, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(210, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(211, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(212, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(213, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(214, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(215, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(216, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '2021-02-22 18:33:57', 0, '', ''),
(217, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(218, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(219, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(220, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(221, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(222, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(223, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(224, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(225, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(226, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(227, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(228, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(229, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(230, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(231, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(232, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(233, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(234, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(235, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(236, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(237, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(238, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(239, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(240, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(241, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(242, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(243, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(244, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(245, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(246, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(247, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(248, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(249, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(250, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(251, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(252, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(253, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(254, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(255, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(256, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(257, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(258, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(259, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(260, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(261, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(262, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(263, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(264, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(265, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(266, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(267, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(268, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(269, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(270, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(271, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(272, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(273, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(274, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(275, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(276, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(277, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(278, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(279, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(280, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(281, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(282, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(283, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(284, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(285, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(286, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(287, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(288, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(289, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(290, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(291, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '2021-02-22 18:33:58', 0, '', ''),
(292, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(293, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(294, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(295, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(296, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(297, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(298, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(299, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(300, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(301, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(302, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(303, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(304, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(305, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(306, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(307, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(308, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(309, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(310, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(311, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(312, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(313, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(314, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(315, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(316, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(317, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(318, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', ''),
(319, 'PR009', 'Anti Biotic', 'Test', 'test', '', 0, 1, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '2021-02-22 18:33:59', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbltaxrate`
--

CREATE TABLE `tbltaxrate` (
  `TaxID` int(11) NOT NULL,
  `TaxRate` double NOT NULL,
  `ActiveTax` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltaxrate`
--

INSERT INTO `tbltaxrate` (`TaxID`, `TaxRate`, `ActiveTax`) VALUES
(2, 123, 0),
(5, 116, 1),
(6, 16.5, 0),
(7, 25, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbltreatmentplan`
--

CREATE TABLE `tbltreatmentplan` (
  `TreatmentPlanID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `Doctor_ID` int(11) NOT NULL,
  `ServiceID` int(11) NOT NULL,
  `TreatmentName` varchar(255) NOT NULL,
  `Description` text DEFAULT NULL,
  `EstimatedCost` decimal(10,2) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `Status` varchar(50) DEFAULT 'Planned',
  `created_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbltreatmentplan`
--

INSERT INTO `tbltreatmentplan` (`TreatmentPlanID`, `PatientID`, `Doctor_ID`, `ServiceID`, `TreatmentName`, `Description`, `EstimatedCost`, `StartDate`, `EndDate`, `Status`, `created_date`) VALUES
(1, 34, 1, 19, 'filling', 'It is the starting stage of the damaging', '5000.00', '2025-04-12', '2025-04-12', 'completed', '2025-04-18 23:38:31'),
(37, 34, 1, 21, 'wistram tooth surgery', 'it is covered with the skin', '30000.00', '2025-04-13', '2025-04-15', 'Pending', '2025-04-18 23:38:31'),
(38, 36, 1, 19, 'filling', 'p[', '5000.00', '2025-04-19', '2025-04-19', 'Completed', '2025-04-18 23:38:31'),
(39, 46, 1, 20, 'crown', 'add a complete crown', '28000.00', '2025-04-19', '2025-05-15', 'On Process', '2025-04-18 23:38:31'),
(40, 50, 1, 24, 'filling', 'normal filling', '5000.00', '2025-04-20', '2025-04-20', 'Completed', '2025-04-18 23:38:31'),
(41, 54, 1, 22, 'bridge', 'tooth is completely damamged so should do bridinig ', '34000.00', '2025-04-20', '2025-05-24', 'On Process', '2025-04-18 23:38:31'),
(42, 58, 1, 21, 'surgery', 'had to remove the broken tooth ', '15000.00', '6754-04-04', '0456-06-04', 'Completed', '2025-04-18 23:38:31'),
(43, 36, 1, 21, 'bridge', 'bridge', '45780.00', '0008-06-05', '0004-03-04', 'Pending', '2025-04-18 23:38:31'),
(44, 41, 1, 19, 'wistram tooth surgery', 'she is having pain als ther is no space for the tooth to come out', '4533.00', '2025-04-13', '2025-04-13', 'Pending', '2025-04-18 23:38:31'),
(45, 58, 1, 22, 'bridge', 'cant do normal filling', '3563.00', '2025-04-13', '2025-04-13', 'Pending', '2025-04-18 23:38:31'),
(46, 36, 1, 24, 'filling', 'normal filling', '76578.00', '2025-04-13', '2025-04-13', 'Pending', '2025-04-18 23:38:31'),
(47, 39, 1, 19, 'filling', 'normal filling', '8979.00', '2025-04-25', '2025-04-26', 'Pending', '2025-04-18 23:38:31'),
(48, 34, 1, 21, 'filling', 'normal filling', '9998.00', '2025-05-10', '2025-05-10', 'Pending', '2025-04-18 23:38:31'),
(49, 39, 1, 19, 'normal filling', 'normal filling', '9999.00', '2025-04-13', '2025-04-15', 'Pending', '2025-04-18 23:38:31'),
(50, 34, 1, 19, 'filling', 'i t had been filled before and now its removed soo o had to fill it again', '10000.00', '2025-04-13', '2025-04-13', 'On Process', '2025-04-18 23:38:31'),
(51, 52, 1, 21, 'surgery', 'infection', '18000.00', '2025-04-23', '2025-04-23', 'Pending', '2025-04-18 23:38:31'),
(52, 65, 1, 19, 'ggg', 'fgh', '7000.00', '2025-04-16', '2025-04-16', 'On Process', '2025-04-18 23:38:31'),
(53, 68, 1, 20, 'filling', 'just a normal filling', '7000.00', '2025-04-18', '2025-04-18', 'Pending', '2025-04-18 23:38:31'),
(54, 68, 1, 19, 'filling', 'normal filling', '7000.00', '2025-04-18', '2025-04-18', 'Pending', '2025-04-18 23:38:31'),
(55, 67, 1, 20, 'crown', 'there is no tooth so we need to add a tooth by doing crown', '152000.00', '2025-04-19', '2025-05-24', 'On Process', '2025-04-18 23:38:31'),
(56, 43, 1, 23, 'xray', 'tooth xray', '1500.00', '2025-04-18', '2025-04-18', 'Completed', '2025-04-18 23:38:31'),
(57, 49, 1, 24, 'filling', 'normal filing', '7000.00', '2025-04-18', '2025-04-18', 'Pending', '2025-04-18 23:38:31'),
(58, 55, 1, 21, 'surgery', 'gjhgjj', '18000.00', '2025-04-17', '2025-04-17', 'Pending', '2025-04-18 23:38:31'),
(59, 51, 1, 19, 'bridge', 'hjiuyhkjbhui', '676.00', '2025-04-17', '2025-04-17', 'On Process', '2025-04-18 23:38:31'),
(60, 58, 1, 19, 'filling', 'normal filling nafee', '7000.00', '2025-04-18', '2025-04-18', 'Completed', '2025-04-18 23:38:31');

-- --------------------------------------------------------

--
-- Table structure for table `tblunit`
--

CREATE TABLE `tblunit` (
  `UnitID` int(11) NOT NULL,
  `Units` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblunit`
--

INSERT INTO `tblunit` (`UnitID`, `Units`) VALUES
(2, 'UNIT');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `UserID` varchar(90) CHARACTER SET latin1 NOT NULL,
  `FullName` varchar(90) CHARACTER SET latin1 NOT NULL,
  `Username` varchar(90) CHARACTER SET latin1 NOT NULL,
  `Pass` varchar(90) CHARACTER SET latin1 NOT NULL,
  `Role` varchar(90) CHARACTER SET latin1 NOT NULL,
  `PicLoc` varchar(255) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`UserID`, `FullName`, `Username`, `Pass`, `Role`, `PicLoc`) VALUES
('USER_014', 'Nafeela Nasri', 'nafeela', '8cb2237d0679ca88db6464eac60da96345513964', 'Administrator', 'photos/icons8-users-96.png'),
('USER_015', 'Nafees Nasri', 'nafees', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'Staff', ''),
('USER_016', 'Ravi weerasinghe', 'ravi', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Doctor', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblappointments`
--
ALTER TABLE `tblappointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `PatientID` (`PatientID`),
  ADD KEY `Doctor_ID` (`Doctor_ID`),
  ADD KEY `fk_service` (`ServiceID`);

--
-- Indexes for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  ADD PRIMARY KEY (`AUTOID`);

--
-- Indexes for table `tblbulkpricing`
--
ALTER TABLE `tblbulkpricing`
  ADD PRIMARY KEY (`BulkID`) USING BTREE;

--
-- Indexes for table `tblcurrency`
--
ALTER TABLE `tblcurrency`
  ADD PRIMARY KEY (`CurrencyID`);

--
-- Indexes for table `tbldiscountrate`
--
ALTER TABLE `tbldiscountrate`
  ADD PRIMARY KEY (`DiscountRateID`);

--
-- Indexes for table `tbldoctors`
--
ALTER TABLE `tbldoctors`
  ADD PRIMARY KEY (`Doctor_ID`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  ADD PRIMARY KEY (`InvoiceID`);

--
-- Indexes for table `tblpatients`
--
ALTER TABLE `tblpatients`
  ADD PRIMARY KEY (`PatientID`);

--
-- Indexes for table `tblpayments`
--
ALTER TABLE `tblpayments`
  ADD PRIMARY KEY (`PaymentID`);

--
-- Indexes for table `tblprescriptions`
--
ALTER TABLE `tblprescriptions`
  ADD PRIMARY KEY (`Prescriptions_ID`);

--
-- Indexes for table `tblprescription_items`
--
ALTER TABLE `tblprescription_items`
  ADD PRIMARY KEY (`Item_ID`),
  ADD KEY `Prescriptions_ID` (`Prescriptions_ID`);

--
-- Indexes for table `tblservices`
--
ALTER TABLE `tblservices`
  ADD PRIMARY KEY (`ServiceID`);

--
-- Indexes for table `tblstocks`
--
ALTER TABLE `tblstocks`
  ADD PRIMARY KEY (`StocksID`);

--
-- Indexes for table `tbltaxrate`
--
ALTER TABLE `tbltaxrate`
  ADD PRIMARY KEY (`TaxID`);

--
-- Indexes for table `tbltreatmentplan`
--
ALTER TABLE `tbltreatmentplan`
  ADD PRIMARY KEY (`TreatmentPlanID`),
  ADD KEY `ServiceID` (`ServiceID`),
  ADD KEY `PatientID` (`PatientID`),
  ADD KEY `Doctor_ID` (`Doctor_ID`);

--
-- Indexes for table `tblunit`
--
ALTER TABLE `tblunit`
  ADD PRIMARY KEY (`UnitID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `tblappointments`
--
ALTER TABLE `tblappointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tblautonumbers`
--
ALTER TABLE `tblautonumbers`
  MODIFY `AUTOID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblbulkpricing`
--
ALTER TABLE `tblbulkpricing`
  MODIFY `BulkID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tblcurrency`
--
ALTER TABLE `tblcurrency`
  MODIFY `CurrencyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbldiscountrate`
--
ALTER TABLE `tbldiscountrate`
  MODIFY `DiscountRateID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldoctors`
--
ALTER TABLE `tbldoctors`
  MODIFY `Doctor_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  MODIFY `InvoiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `tblpatients`
--
ALTER TABLE `tblpatients`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `tblpayments`
--
ALTER TABLE `tblpayments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `tblprescriptions`
--
ALTER TABLE `tblprescriptions`
  MODIFY `Prescriptions_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblprescription_items`
--
ALTER TABLE `tblprescription_items`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblservices`
--
ALTER TABLE `tblservices`
  MODIFY `ServiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tblstocks`
--
ALTER TABLE `tblstocks`
  MODIFY `StocksID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=320;

--
-- AUTO_INCREMENT for table `tbltaxrate`
--
ALTER TABLE `tbltaxrate`
  MODIFY `TaxID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbltreatmentplan`
--
ALTER TABLE `tbltreatmentplan`
  MODIFY `TreatmentPlanID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tblunit`
--
ALTER TABLE `tblunit`
  MODIFY `UnitID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblappointments`
--
ALTER TABLE `tblappointments`
  ADD CONSTRAINT `fk_service` FOREIGN KEY (`ServiceID`) REFERENCES `tblservices` (`ServiceID`) ON DELETE SET NULL,
  ADD CONSTRAINT `tblappointments_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `tblpatients` (`PatientID`),
  ADD CONSTRAINT `tblappointments_ibfk_2` FOREIGN KEY (`Doctor_ID`) REFERENCES `tbldoctors` (`Doctor_ID`);

--
-- Constraints for table `tblprescription_items`
--
ALTER TABLE `tblprescription_items`
  ADD CONSTRAINT `tblprescription_items_ibfk_1` FOREIGN KEY (`Prescriptions_ID`) REFERENCES `tblprescriptions` (`Prescriptions_ID`) ON DELETE CASCADE;

--
-- Constraints for table `tbltreatmentplan`
--
ALTER TABLE `tbltreatmentplan`
  ADD CONSTRAINT `tbltreatmentplan_ibfk_1` FOREIGN KEY (`ServiceID`) REFERENCES `tblservices` (`ServiceID`),
  ADD CONSTRAINT `tbltreatmentplan_ibfk_2` FOREIGN KEY (`PatientID`) REFERENCES `tblpatients` (`PatientID`),
  ADD CONSTRAINT `tbltreatmentplan_ibfk_3` FOREIGN KEY (`Doctor_ID`) REFERENCES `tbldoctors` (`Doctor_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
