<?php

session_start();

if (!isset($_SESSION['ID']) || $_SESSION['ROLE'] != 'Doctor') {
    header("Location: login.php");
    exit;
}

// Doctor-specific layout
include('doctorheader.php'); // if you have one

?>